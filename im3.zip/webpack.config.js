'use strict';

module.exports = {
    entry: './src/js/s.js',
    output: {
        path: __dirname + '/public',
        filename: 's.js'
    }
}